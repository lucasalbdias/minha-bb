# 🚀 Guia Completo: Como Hospedar no Netlify

## ✅ O que eu já fiz por você:

Adicionei o arquivo `netlify.toml` no seu projeto com as configurações corretas!

---

## 📋 Passo a Passo para Hospedar

### **Método 1: Deploy via GitHub (RECOMENDADO)**

#### 1️⃣ Prepare seu projeto
- Extraia o arquivo zip que vou te enviar
- Abra a pasta no seu computador

#### 2️⃣ Suba para o GitHub
1. Crie um repositório novo no GitHub
2. No terminal/CMD, dentro da pasta do projeto, rode:
   ```bash
   git init
   git add .
   git commit -m "Primeiro commit - Projeto Princesa"
   git branch -M main
   git remote add origin SEU-LINK-DO-GITHUB
   git push -u origin main
   ```

#### 3️⃣ Conecte ao Netlify
1. Acesse [netlify.com](https://netlify.com) e faça login
2. Clique em **"Add new site"** → **"Import an existing project"**
3. Escolha **GitHub** e autorize
4. Selecione seu repositório
5. Configure assim:
   - **Build command:** `npm run build`
   - **Publish directory:** `dist`
6. Clique em **Deploy**

---

### **Método 2: Deploy Direto (Arrastar e Soltar)**

#### 1️⃣ Faça o build localmente
No terminal, dentro da pasta do projeto:
```bash
npm install
npm run build
```

Isso vai criar uma pasta chamada `dist`

#### 2️⃣ Suba para o Netlify
1. Acesse [netlify.com](https://netlify.com)
2. Faça login
3. Arraste a pasta `dist` para onde diz **"Want to deploy a new site without connecting to Git? Drag and drop your site output folder here"**

---

## 🔧 Problemas Comuns e Soluções

### ❌ Erro: "Build failed"
**Solução:**
- Certifique-se que tem o Node.js instalado (versão 18+)
- Rode `npm install` antes de `npm run build`
- Verifique se o arquivo `netlify.toml` está na raiz do projeto

### ❌ Página em branco após deploy
**Solução:**
- Já está resolvido! O arquivo `netlify.toml` que adicionei corrige isso
- Se ainda assim der problema, nas configurações do Netlify:
  - Vá em **Site settings** → **Build & deploy** → **Post processing**
  - Ative **Asset optimization**

### ❌ Imagens ou fontes não carregam
**Solução:**
- Verifique se todos os arquivos estão na pasta `dist` depois do build
- Use caminhos relativos (sem `/` no início)

---

## 🎯 Checklist Final

Antes de fazer deploy, confirme:
- [ ] Arquivo `netlify.toml` está na raiz do projeto ✅
- [ ] `package.json` e `package-lock.json` estão presentes ✅
- [ ] Pasta `src` com todos os arquivos ✅
- [ ] Arquivo `index.html` na raiz ✅
- [ ] Todos os arquivos de configuração (vite, tailwind, etc.) ✅

---

## 📱 Depois do Deploy

Quando o deploy terminar, você vai receber:
- Um link como `https://seu-site.netlify.app`
- Você pode personalizar esse link em **Site settings** → **Domain management**

---

## 💡 Dicas Extras

1. **Domínio personalizado:** Você pode adicionar seu próprio domínio nas configurações
2. **HTTPS automático:** O Netlify já ativa SSL automaticamente
3. **Atualizações:** Se conectou pelo GitHub, cada push atualiza o site automaticamente!

---

**Dúvidas?** Me chama que eu te ajudo! 😊
